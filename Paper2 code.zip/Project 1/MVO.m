function  x = MVO(mu, Q, targetRet,tickers)
    
    % Use this function to construct your MVO portfolio subject to the
    % target return, with short sales disallowed. 
    %
    % You may use quadprog, Gurobi, or any other optimizer you are familiar
    % with. Just be sure to comment on your code to (briefly) explain your
    % procedure.

    % Find the total number of assets
    n = size(Q,1); 

    % *************** WRITE YOUR CODE HERE ***************
    %----------------------------------------------------------------------
    % Total of 20 out of n total assets 
mu = [mu zeros(1,n)]; 
Q  = [Q zeros(n); zeros(n,2*n)];

% We have 2n buy-in constraints (lower and upper bounds), and each
% constraint defines the lower or upper bound by pairing a single asset
% weight with its corresponding auxiliary variable. This matrix will be of
% dimension 2n * 2n We dont have buy in constraints

%B = none

% We must also include the target return constraint. We can add another row
% onto matrix B to account for the target return constraint. Therefore, our
% complete matrix A will have dimension (2n + 1) * 2n. However, since the
% lower constraint is 0 and the upper constraint is 1 Liyi-xi <= 0 is
% equivalent to xi >= 0, which is reflected in the boundaries. Them we
% would have (n+1)*2n for matrix A 21x40

A =  [eye(n) -eye(n); mu];

% We must also define the right-hand side coefficients of the inequality 
% constraints, b, which is a column vector of dimension (2n + 1); as shown
% above this should be n+1 in our case

b = [zeros(n,1) ;     targetRet];

% We only have 2 equality constraints: the cardinality constraint (sum of
% y's) and the budget constraint (sum of x's):
Aeq = [ones(1,n) zeros(1,n);zeros(1,n) ones(1,n)];

% We must also define the right-hand side coefficients of the equality 
% constraints, beq:
beq = [1 n]';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% PART 4: Setup Gurobi model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%--------------------------------------------------------------------------
% 4.1 Define the model variables and assign them a name
%--------------------------------------------------------------------------

% Define the variable types:'C' defines a continuous variable, 'B' defines
% a binary variable
varTypes = [repmat('C', n, 1); repmat('B', n, 1)];

% Input the lower and upper bounds. Since our lower buy-in threshold is
% 0.05, this means we are not allowed to short-sell.
lb = zeros(2*n, 1);
ub = ones(2*n, 1); 

% Append '_c' to cont var. names
namesCont = cellfun(@(c)[c '_c'], tickers(1:n), 'uni', false); 

% Append '_b' to binary var. names
namesBin = cellfun(@(c)[c '_b'], tickers(1:n), 'uni', false); 

% Combine both name vectors
names = [namesCont namesBin];

%--------------------------------------------------------------------------
% 4.1 Setup the Gurobi model
%--------------------------------------------------------------------------
clear model;

% Assign the variable names
model.varnames = names;

% Gurobi accepts an objective function of the following form:
% f(x) = x' Q x + c' x 

% Define the Q matrix in the objective 
model.Q = sparse(Q);

% define the c vector in the objective (which is a vector of zeros since
% there is no linear term in our objective)
model.obj = zeros(1, 2*n);

% Gurobi only accepts a single A matrix, with both inequality and equality
% constraints
model.A = [sparse(A); sparse(Aeq)];

% Define the right-hand side vector b
model.rhs = full([b; beq]);

% Indicate whether the constraints are ">=", "<=", or "="
model.sense = [ repmat('<', (n + 1), 1) ; repmat('=', 2, 1) ]; %change from 2n+1 to n+1

% Define the variable type (continuous, integer, or binary)
model.vtype = varTypes;

% Define the variable upper and lower bounds
model.lb = lb;
model.ub = ub;

% Set some Gurobi parameters to limit the runtime and to avoid printing the
% output to the console. 
clear params;
params.TimeLimit = 100;
params.OutputFlag = 0;

results = gurobi(model,params);

%fprintf('Optimal obj. value: %1.6f \n\nAsset weights:\n', results.objval);

%for i=1:n
%    if(results.x(n+i) ~= 0)
%        fprintf('   (+) %3s %1.6f\n', tickers{i}, results.x(i));
%    end
%end
    % x =           % Optimal asset weights
    %----------------------------------------------------------------------
x = results.x(1:n,:);
return;
end