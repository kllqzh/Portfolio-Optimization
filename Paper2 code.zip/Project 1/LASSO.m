function  [mu, Q, num_Var,Beta] = LASSO(returns, factRet, lambda, K,tickers)
    
    % Use this function for the LASSO model. Note that you will not use K 
    % in this model (K is for BSS).
    %
    % You should use an optimizer to solve this problem. Be sure to comment 
    % on your code to (briefly) explain your procedure.
    
    % *************** WRITE YOUR CODE HERE ***************
    %----------------------------------------------------------------------
    % Use this function for the LASSO model. Note that you will not use K 
    % in this model (K is for BSS).
    %
    % You should use an optimizer to solve this problem. Be sure to comment 
    % on your code to (briefly) explain your procedure.
    
    % *************** WRITE YOUR CODE HERE ***************
    %----------------------------------------------------------------------
    
   
[n, m] = size(factRet);
var_n = m+1;
f = factRet;
r = returns;
X = [ones(n,1) f];
X_new=[X,zeros(n,m+1)];
%H=X_new'*X_new;
H=[X'*X,zeros(var_n,var_n); zeros(var_n,2*var_n)];
stk_n = size(returns, 2);
%B_ans=["f1";"f2";"f3";"f4";"f5";"f6";"f7";"f8";"f9";"f1";"f2";"f3";"f4";"f5";"f6";"f7";"f8";"f9"];
B_ans=[];
for i=1:stk_n
    b_new=zeros(2*var_n,1);
    r_new=r(:,i);
    ones_new=[zeros(1,m+1),ones(1,m+1)];
    f_new=-2*r_new'*X_new+lambda*ones_new;
    A_new=[eye(m+1),-eye(m+1);
        -eye(m+1),-eye(m+1)];

    options = optimoptions('quadprog','TolFun',1e-9);
    x_ans = quadprog(H, f_new', A_new, b_new, [], [], [], [], [], options );
    B_ans=[B_ans,x_ans];
end 
B_1=B_ans(1:m+1,1:stk_n);
%{
for c = 1:20
 for r = 1:9
 if B_1(r,c)>1e-5
 B_1(r,c)=B_1(r,c);
 elseif B_1(r,c)<-1e-5
 B_1(r,c)=B_1(r,c);
 else
 B_1(r,c)=0;
 end
 end
 end
%}
f_avg = [ones(1,1) (geomean(f + 1) - 1)];
a = f_avg * B_1;
mu = a(:,1:20);
    %Calculate the err in order to create the D matrix
    XB = X*B_1;
    err = r - XB;
    %std_err = sqrt((1/(n-m-1)) * norm(err, 'fro')^2);
    stk_n = size(err, 2);  % number of columns in A
    D = diag(zeros(stk_n, 1));  % initialize diagonal matrix
    
    for i = 1:stk_n
        col = err(:, i);  % extract column i
        D(i, i) = (1/(n-m-1)) * norm(col, 'fro')^2;  % calculate L2 norm and store in diagonal matrix
    end
    F = cov(f);
    V = B_1(2:end,:);
    Q= V' * F * V + D;
count_var=0;
    for c = 1:20
    for r = 1:9
        if B_1(r,c)>1e-5
            count_var=count_var+1;
        elseif B_1(r,c)<-1e-5
            count_var=count_var+1;
        else
            count_var=count_var;
        end
    end
end
    num_Var = count_var/20;
    Beta=B_1;

    return;
    
    % mu =          % n x 1 vector of asset exp. returns
    % Q  =          % n x n asset covariance matrix
    %----------------------------------------------------------------------
    
end