   clc
clear all
format short
% Load the stock weekly prices
adjClose = readtable('MMF1921_AssetPrices.csv');
adjClose.Properties.RowNames = cellstr(datetime(adjClose.Date));
adjClose.Properties.RowNames = cellstr(datetime(adjClose.Properties.RowNames));
adjClose.Date = [];

% Load the factors weekly returns
factorRet = readtable('MMF1921_FactorReturns.csv');
factorRet.Properties.RowNames = cellstr(datetime(factorRet.Date));
factorRet.Properties.RowNames = cellstr(datetime(factorRet.Properties.RowNames));
factorRet.Date = [];

riskFree = factorRet(:,9);
factorRet = factorRet(:,1:8);

% Identify the tickers and the dates 
tickers = adjClose.Properties.VariableNames';
dates   = datetime(factorRet.Properties.RowNames);

% Calculate the stocks' weekly EXCESS returns
prices  = table2array(adjClose);
returns = ( prices(2:end,:) - prices(1:end-1,:) ) ./ prices(1:end-1,:);
returns = returns - ( diag( table2array(riskFree) ) * ones( size(returns) ) );
returns = array2table(returns);
returns.Properties.VariableNames = tickers;
returns.Properties.RowNames = cellstr(datetime(factorRet.Properties.RowNames));

% Align the price table to the asset and factor returns tables by
% discarding the first observation.
adjClose = adjClose(2:end,:);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 2. Define your initial parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Initial budget to invest ($100,000)
initialVal = 100000;

% Start of in-sample calibration period 
calStart = datetime('2008-01-01');
calEnd   = calStart + calyears(4) - days(1);

% Start of out-of-sample test period 
testStart = datetime('2012-01-01');
testEnd   = testStart + calyears(1) - days(1);

% Number of investment periods (each investment period is 1 year long)
NoPeriods = 5;

% Factor models
% Note: You must populate the functios OLS.m, FF.m, LASSO.m and BSS.m with your
% own code.
FMList = {'OLS' 'FF' 'LASSO'};
FMList = cellfun(@str2func, FMList, 'UniformOutput', false);
NoModels = length(FMList);

% Tags for the portfolios under the different factor models
tags = {'OLS portfolio' 'FF portfolio' 'LASSO portfolio'};

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 3. Construct and rebalance your portfolios
%
% Here you will estimate your input parameters (exp. returns and cov. 
% matrix etc) from the Fama-French factor models. You will have to 
% re-estimate your parameters at the start of each rebalance period, and 
% then re-optimize and rebalance your portfolios accordingly. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Initiate counter for the number of observations per investment period
toDay = 0;

% Preallocate the space for the per period value of the portfolios 
currentVal = zeros(NoPeriods, NoModels);
R2_in = zeros(NoPeriods,NoModels);
PortRe_out = zeros(NoPeriods,NoModels);

%--------------------------------------------------------------------------
% Set the value of lambda and K for the LASSO and BSS models, respectively
%--------------------------------------------------------------------------
lambda = 1;
K      = 4;

t = 1;
  
    % Subset the returns and factor returns corresponding to the current
    % calibration period.
    periodReturns = table2array( returns( calStart <= dates & dates <= calEnd, :) );
    periodFactRet = table2array( factorRet( calStart <= dates & dates <= calEnd, :) );
    currentPrices = table2array( adjClose( ( calEnd - days(7) ) <= dates ... 
                                                    & dates <= calEnd, :) )';
    
    % Subset the prices corresponding to the current out-of-sample test 
    % period.
    periodPrices = table2array( adjClose( testStart <= dates & dates <= testEnd,:) );
    
    % Set the initial value of the portfolio or update the portfolio value
    if t == 1
        
        currentVal(t,:) = initialVal;
        
    else
        for i = 1 : NoModels
            
            currentVal(t,i) = currentPrices' * NoShares{i};
            
        end
    end
    
    % Update counter for the number of observations per investment period
    fromDay = toDay + 1;
    toDay   = toDay + size(periodPrices,1);
factRet = periodFactRet;
[n, m] = size(factRet);

f = factRet;
r = periodReturns;
X = [ones(n,1) f];
X_new=[X,zeros(n,m+1)];
%H=X_new'*X_new;
H=[X'*X,zeros(m+1,m+1);
    zeros(m+1,2m+2)];
stk_n = size(periodReturns, 2);
%B_ans=["f1";"f2";"f3";"f4";"f5";"f6";"f7";"f8";"f9";"f1";"f2";"f3";"f4";"f5";"f6";"f7";"f8";"f9"];
B_ans=[];
for i=1:stk_n
    b_new=zeros(2m+2,1);
    r_new=r(:,i);
    ones_new=[zeros(1,m+1),ones(1,m+1)];
    f_new=-2*r_new'*X_new+lambda*ones_new;
    A_new=[eye(m+1),-eye(m+1);
        -eye(m+1),-eye(m+1)];

    options = optimoptions('quadprog','TolFun',1e-9);
    x_ans = quadprog(H, f_new', A_new, b_new, [], [], [], [], [], options );
    B_ans=[B_ans,x_ans];
end 
B_1=B_ans(1:m+1,1:stk_n);
for c = 1:stk_n
    for r = 1:m+1
        if B_1(r,c)>1e-5
            B_1(r,c)=B_1(r,c);
        elseif B_1(r,c)<-1e-5
            B_1(r,c)=B_1(r,c);
        else
            B_1(r,c)=0;
        end
    end
end

f_avg = [ones(1,1) (geomean(f + 1) - 1)];
mu = f_avg * B_1;
mu = mu';
    %Calculate the err in order to create the D matrix
    XB = X*B_1;
    err = r - XB;
    %std_err = sqrt((1/(n-m-1)) * norm(err, 'fro')^2);
    stk_n = size(err, 2);  % number of columns in A
    D = diag(zeros(stk_n, 1));  % initialize diagonal matrix
    
    for i = 1:stk_n
        col = err(:, i);  % extract column i
        D(i, i) = (1/(n-m-1)) * norm(col, 'fro')^2;  % calculate L2 norm and store in diagonal matrix
    end
    F = cov(f);
    V = B_1(2:end,:);
    Q= V' * F * V + D;
    return;
    
    % mu =          % n x 1 vector of asset exp. returns
    % Q  =          % n x n asset covariance matrix
    %-----
   