function  [mu, Q,num_Var,Beta] = FF(returns, factRet, lambda, K)
    
    % Use this function to calibrate the Fama-French 3-factor model. Note 
    % that you will not use lambda or K in this model (lambda is for LASSO, 
    % and K is for BSS).
 
    % *************** WRITE YOUR CODE HERE ***************
    %----------------------------------------------------------------------
    
    % First convert the table into arrays
    FR = factRet(:, 1:3);
    [n, m] = size(FR); %n is T; m is factor numbers
    f = FR;
    r = returns;
    X = [ones(n,1) f];
    XTX = X' * X;
    XTX_inv = inv(XTX);
    %Calculating the estimated alpha and beta
    B = XTX_inv * X' * r;
    %Calculate mu
    f_avg = [ones(1,1) (geomean(f + 1) - 1)]; %8x1
    mu = f_avg * B;
    %Calculate the err in order to create the D matrix
    XB = X*B;
    err = r - XB;
    %std_err = sqrt((1/(n-m-1)) * norm(err, 'fro')^2);
    stk_n = size(err, 2);  % number of columns in A
    D = diag(zeros(stk_n, 1));  % initialize diagonal matrix
    
    for i = 1:stk_n
        col = err(:, i);  % extract column i
        D(i, i) = (1/(n-m-1)) * norm(col, 'fro')^2;  % calculate L2 norm and store in diagonal matrix
    end
    F = cov(f);
    V = B(2:end,:);
    Q= V' * F * V + D;
    num_Var = nnz(sum(B, 2));
    Beta=B;
    return;
    % mu =          % n x 1 vector of asset exp. returns
    % Q  =          % n x n asset covariance matrix
    %----------------------------------------------------------------------
    
end