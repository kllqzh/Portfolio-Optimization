function  [mu, Q] = BSS(returns, factRet,lambda,K)
    
    % Use this function for the BSS model. Note that you will not use 
    % lambda in this model (lambda is for LASSO).
    %
    % You should use an optimizer to solve this problem. Be sure to comment 
    % on your code to (briefly) explain your procedure.
    
 
    % *************** WRITE YOUR CODE HERE ***************
    %----------------------------------------------------------------------  
[n, m] = size(factRet);
f = factRet;
r = returns;
X = [ones(n,1) f];
var_n = m+1;
X_new=[X,zeros(n,var_n)];
H=X_new'*X_new;
stk_n = size(returns, 2);
%B_ans=["f1";"f2";"f3";"f4";"f5";"f6";"f7";"f8";"f9";"f1";"f2";"f3";"f4";"f5";"f6";"f7";"f8";"f9"];
B_ans=[];
for i=1:stk_n
    b_new=[zeros(1,var_n),ones(1,var_n)];
    r_new=r(:,i);
    %ones_new=[zeros(1,9),ones(1,9)];
    f_new=-2*r_new'*X_new;
    A_new=[-eye(var_n),-100 * eye(var_n);
        eye(var_n),-100 * eye(var_n)];

    %options = optimoptions('quadprog','TolFun',1e-9);
    %x_ans = quadprog(H,f_new',b_new,4, [], [], [], [], [], options );

%--------------------------------------------------------------------------


Q=[X'*X,zeros(var_n,var_n);
    zeros(var_n,2*var_n)];
b_new2=zeros(2*var_n,1);

% Gurobi accepts an objective function of the following form:
% f(x) = x' Q x + c' x 

%H=[H,zeros(9,9);zeros(18,9)];
% Define the Q matrix in the objective 
model.Q = sparse(Q);

% define the c vector in the objective (which is a vector of zeros since
% there is no linear term in our objective)
f_new=-2*r_new'*X_new;
model.obj = f_new;

% Gurobi only accepts a single A matrix, with both inequality and equality
% constraints
model.A = [sparse(A_new);sparse(b_new)];

% Define the right-hand side vector b
model.rhs = [b_new2;K];

% Indicate whether the constraints are ">=", "<=", or "="
model.sense = [ repmat('<', 2*var_n, 1); repmat('=', 1, 1)];

% Define the variable type (continuous, integer, or binary)
varTypes = [repmat('C', var_n, 1); repmat('B', var_n, 1)];
model.vtype = varTypes;
model.modelsense = 'min';
%model.AddVar(vtype=GRB.BINARY)
% Set some Gurobi parameters to limit the runtime and to avoid printing the
% output to the console. 
clear params;
params.TimeLimit = 100;
params.OutputFlag = 0;

results = gurobi(model,params);
B_ans1=results.x;
B_ans=[B_ans,B_ans1];
end
B_ansf=B_ans(1:var_n,1:stk_n);
f_avg = [ones(1,1) (geomean(f + 1) - 1)]; %8x1
a = f_avg * B_ansf;
mu = a(:,1:stk_n)';
    %Calculate the err in order to create the D matrix
    XB = X*B_ansf;
    err = r - XB;
    %std_err = sqrt((1/(n-m-1)) * norm(err, 'fro')^2);
    stk_n = size(err, 2);  % number of columns in A
    D = diag(zeros(stk_n, 1));  % initialize diagonal matrix
    
    for i = 1:stk_n
        col = err(:, i);  % extract column i
        D(i, i) = (1/(n-m-1)) * norm(col, 'fro')^2;  % calculate L2 norm and store in diagonal matrix
    end
    F = cov(f);
    V = B_ansf(2:end,:);
    Q= V' * F * V + D;
    return;
    
    
    
    % mu =          % n x 1 vector of asset exp. returns
    % Q  =          % n x n asset covariance matrix
    %----------------------------------------------------------------------
    
end